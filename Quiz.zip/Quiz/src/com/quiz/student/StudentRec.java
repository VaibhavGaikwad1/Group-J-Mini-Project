package com.quiz.student;

public interface StudentRec {
public void fetchRecord(int id);

}
